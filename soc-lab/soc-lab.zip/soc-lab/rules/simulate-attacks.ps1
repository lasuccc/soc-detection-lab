# Attack simulations to validate the detection rules.
# Run in an elevated PowerShell session on the domain controller.
# Each block triggers a specific rule so you can confirm it fires
# in the Wazuh dashboard.

# --- Brute force -> triggers rule 100100 ---
# Eight failed logons against a non-existent account, ~2s apart,
# comfortably clearing the threshold of 5 within 120 seconds.
$user = "lab\fakeuser"
$pass = ConvertTo-SecureString "WrongPassword123" -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential($user, $pass)
1..8 | ForEach-Object {
    try { Start-Process cmd -Credential $cred -ErrorAction Stop } catch {}
    Start-Sleep -Seconds 2
}

# --- Privilege escalation -> triggers rules 100201 and 100200 ---
# Create a test account, add it to local Administrators (4732),
# then to Domain Admins (4728).
net user attacker P@ssw0rd123! /add
net localgroup Administrators attacker /add
Add-ADGroupMember -Identity "Domain Admins" -Members attacker

# --- Cleanup: remove the rogue account after testing ---
# Remove-ADGroupMember -Identity "Domain Admins" -Members attacker -Confirm:$false
# net user attacker /delete
