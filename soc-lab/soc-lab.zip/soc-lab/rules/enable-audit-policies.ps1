# Enable the Windows audit policies the detection rules depend on.
# Run in an elevated PowerShell session on the domain controller.
# Without these, Event IDs 4625, 4672, 4728 and 4732 either don't
# generate or arrive with no useful detail.

auditpol /set /subcategory:"Logon" /success:enable /failure:enable
auditpol /set /subcategory:"Logoff" /success:enable
auditpol /set /subcategory:"Account Lockout" /success:enable /failure:enable
auditpol /set /subcategory:"Special Logon" /success:enable
auditpol /set /subcategory:"Security Group Management" /success:enable /failure:enable
auditpol /set /subcategory:"User Account Management" /success:enable /failure:enable
auditpol /set /subcategory:"Process Creation" /success:enable

Write-Host "Audit policies applied. Verify with: auditpol /get /category:*"
