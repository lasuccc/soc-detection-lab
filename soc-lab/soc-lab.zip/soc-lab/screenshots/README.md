# Screenshots

Drop your dashboard evidence here. Suggested captures:

- `dashboard-overview.png` — the Threat Hunting overview showing total
  events, level 12+ alerts, and authentication success/failure counts
- `bruteforce-alert.png` — rule 100100 firing after the simulated attack
- `privesc-alert.png` — rule 100200 / 100201 firing on a group change

Before uploading, a quick privacy pass: private IPs (10.x) and the
instance hostname are fine to show since the instance is disposable.
Never post the public IP or the contents of your `.pem` key.
