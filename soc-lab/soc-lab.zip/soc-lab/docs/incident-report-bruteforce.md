# Incident Report: Brute Force Detection

**Detection rule:** 100100
**MITRE ATT&CK:** T1110 (Brute Force)
**Severity:** Level 10 (high)
**Analyst:** Lucas Harman

## Summary

The SIEM raised a high-severity alert after an account failed to log
on eight times inside 20 seconds, all against the domain controller.
This is consistent with a password-guessing attack rather than a user
mistyping a password.

## Timeline

| Time (UTC) | Event |
|------------|-------|
| 17:00:01 | First failed logon (Event ID 4625) against account `fakeuser` |
| 17:00:01 to 17:00:15 | Seven further failed logons for the same account |
| 17:00:15 | Rule 100100 correlated 5+ failures within the window and fired |

## Evidence

Each individual failure matched Wazuh's built-in rule 60122 ("Logon
Failure - Unknown user or bad password") from Windows Event ID 4625.
The manager's alert log recorded the correlation firing:

```
Rule: 60122 (level 5) -> 'Logon Failure - Unknown user or bad password'
...
Rule: 100100 (level 10) -> 'Possible brute force: 5+ failed Windows logons in 2 minutes'
```

## Detection logic

Rule 100100 counts occurrences of rule 60122 and fires when it sees
five or more within a 120-second window. The threshold separates
normal user error (one or two failures) from an automated or manual
guessing attempt.

## A real detection-engineering lesson

The first version of the rule used `<same_source_ip />` to correlate
failures by origin. It never fired, despite the failures clearly
arriving. The cause: the attack used a local logon, which does not
populate a source IP field, so the rule had nothing to group on.

Network-based brute force (RDP or SMB from another host) does populate
a source IP, so `same_source_ip` works there. Local attempts don't.
In production you would run both variants. Removing the source-IP
correlation and counting on frequency alone resolved it for this lab.

## Recommended response

In a live environment this alert would warrant:

1. Confirming whether the targeted account exists and is privileged
2. Checking the source of the attempts and blocking it at the firewall
3. Locking or resetting the account if a compromise is suspected
4. Reviewing whether account-lockout policy thresholds are appropriate
